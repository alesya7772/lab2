import win32com.client
import os

#Обращаемся к экселю
Excel = win32com.client.Dispatch("Excel.Application")

#Получаем путь к папке + название файла
filePath = os.path.dirname(__file__) + "/ExcelFileTemplate.xlsx"

#Получаем рабочую книгу
workBook = Excel.Workbooks.Open(filePath)

#Получаем сам лист в файле
workSheet = workBook.ActiveSheet

#Получаем использованную область
usedRange = workSheet.UsedRange

#Из области достаем количество строк
rowsCount = usedRange.Rows.Count

#И колонок
columnsCount = usedRange.Columns.Count

#Создаем путь к файлу Excel в котором будет результат замены
resultFilePath = os.path.dirname(__file__) + "/ExcelFileResult.xlsx"

#Промеряем есть ли такой файл, если есть то заменяем на новый, если нет то создаем
resultWorkBook = None
if os.path.exists(resultFilePath):
    resultWorkBook = Excel.Workbooks.Open(resultFilePath)
else:
    resultWorkBook = Excel.Workbooks.Add()

resultWorkSheet = resultWorkBook.ActiveSheet

#Проходимся по всем строкам и колонкам и заменяем метки на нужный текст
for row in range(rowsCount):
    for column in range(columnsCount):
        val = str(workSheet.Cells(row + 1, column + 1).value)
        
        resultWorkSheet.Cells(row + 1, column + 1).value = val

        if(val.startswith("{{") & val.endswith("}}")):
            print("Текст для замены метки " + val + " -> ")

            replace = input()

            resultWorkSheet.Cells(row + 1, column + 1).value = replace

if os.path.exists(resultFilePath):
    resultWorkBook.Save()
else:
    resultWorkBook.SaveAs(os.path.dirname(os.path.realpath(__file__)) + "\\ExcelFileResult.xlsx")

resultWorkBook.Close()

workBook.Close()
Excel.Quit()

print("Сохранено!")